﻿######################################################
# Create Task schedule for TimeBox
# Version 2.0 , date : 3-6-2018
# Writtern by Harikanth
# Usage : TimeBox.ps1 login_time Logout_time
#
######################################################

[string]$login = $args[0]
[string]$logout = $args[1]
ipmo ScheduledTasks

$set = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries
$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument '-NoProfile -WindowStyle Hidden -command "start chrome http://10.43.14.149/TimeBox/index.html"'

$check1 = Get-ScheduledTask "Login" -ErrorAction SilentlyContinue

if($check1.TaskName -match "Login"){
$del = Unregister-ScheduledTask -TaskName "Login" -Confirm:$False
	$trigger =  New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday, Tuesday, Wednesday, Thursday, Friday -At $login
	Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "Login" -Description "Time Box trigger" -Settings $set
}

else
{
	# Create Login task
	$trigger =  New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday, Tuesday, Wednesday, Thursday, Friday -At $login
	Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "Login" -Description "Time Box trigger" -Settings $set
}


$check2 = Get-ScheduledTask "Logout" -ErrorAction SilentlyContinue
 
if($check2.TaskName -match "Logout"){
$del = Unregister-ScheduledTask -TaskName "Logout" -Confirm:$False
	$trigger =  New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday, Tuesday, Wednesday, Thursday, Friday -At $logout
	Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "Logout" -Description "Time Box trigger" -Settings $set
}
else
{
	# Create Logout task
	$trigger =  New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday, Tuesday, Wednesday, Thursday, Friday -At $logout
	Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "Logout" -Description "Time Box trigger" -Settings $set
}